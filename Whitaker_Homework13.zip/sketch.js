  var px = 50; // player x
  var py = 50; // player y
  var pdiameter = 50; // player diameter
  var x = 25
  var y = 25
  var diameter = 25
  var mousex = 0;
  var mousey = 0;
  var oXs = []; // x array for obstacles
  var oYs = []; // y array for obstacles
  var oDs = []; // Diameter array for obstacles

  
function setup()
  {
    createCanvas(800,600);
    
      for(var i = 0; i < 10; i++)
        {
          // get all the random values for circle obstacles
          oXs[i] = getRoX(800);
          oYs[i] = getRoY(600);
          oDs[i] = getRoD(100);
        }
  }

function draw()
  {
    background(100,56,125);
      
    createPlayer(); // call function to create player
    
    movePlayer(); // call function to move player
    
    createExit(); // call function to create exit
        
    youWin(); // call function to track player movement and display message
    
    mouseCircle(); // call function to create mouse circle
    
    for(var i = 0; i < oXs.length; i++) // for loop to create random circles/colors
    {
fill(Math.floor(Math.random()*256,Math.floor(Math.random()*256),Math.floor(Math.random()*256)));
        circle(oXs[i], oYs[i], oDs[i]);
    }   
    
    moveOs(); // call function to move obstacles
    
  }
    function moveOs()
{
    /*
    define function that "should" move obstacles randomly and then "should" make    
    them go back to the other side of the canvas if they exit
    */
    for(var i = 0; i < oXs.length; i++)
    {     
        if(oXs[i] <= 800)
        {
        oXs[i]+=Math.random();
        }
        else
        {
        oXs[i]=2;
        }
        if(oYs[i] <= 600)
        {
        oYs[i]+=Math.random();
        }
        else
        {
        oYs[i]=2;
        }
      }
    }

    function getRoX(x)// 
    {
        return Math.floor(Math.random()*x)+10;
    }

    function getRoY(y)
    {
        return Math.floor(Math.random()*y) + 10;
    }

    function getRoD(diameter)
    {
        return Math.floor(Math.random()*diameter)+10
    }
   
    function mousePressed() // call mouse pressed function to track mouse x & y
    {  
      mousex = mouseX;
      mousey = mouseY;
    }

    function mouseCircle()
    {
      fill(5,100,5);
      circle(mousex,mousey,35);
    }
    
    function createPlayer() // define function that creates the player
    {
      fill(0,0,255);
      circle(px,py,pdiameter);
      fill(0);
      textSize(16);
      text('Player',15,20);
    }
    
    function movePlayer() //  define function that moves the player
    {
      if(keyIsDown(68))
      {
      px+=5;
      }
      else if(keyIsDown(65))
      {
      px-=5;
      }
      else if(keyIsDown(83))
      {
      py+=5;
      }
      else if(keyIsDown(87))
      {
      py-=5;
      }
    }
    
    function createExit() // define function that creates exit
    {
      fill(0,255,0);
      rect(700,400,100,200);
      fill(0)
      textSize(30)
      text('Exit',725,515)
    }
    
    function youWin() 
    /* 
    define function that tracks player movement and displays the message
    */
    {
      if(px >= 700 && py >= 400)
      {
      textSize(60);
      fill(255,255,255);
      text('You win! Thanks for playing!',27,300);
      }
    }